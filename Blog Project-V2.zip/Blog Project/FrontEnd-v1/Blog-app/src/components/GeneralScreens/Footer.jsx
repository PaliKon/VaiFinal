import React from 'react';
import '../../Css/Footer.css'

const Footer = () => {
    return (
        <div>
            <div className="footer">
            </div>
            <div className="copyright">
            </div>
        </div>
    )
}

export default Footer;
