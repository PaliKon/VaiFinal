const dotenv = require("dotenv");
dotenv.config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");

const IndexRoute = require("./Routers/index");
const connectDatabase = require("./Helpers/database/connectDatabase");
const customErrorHandler = require("./Middlewares/Errors/customErrorHandler");

// const limiter = rateLimit({
//   windowMs: 15 * 60 * 1000,
//   max: 1000,
// });

connectDatabase();
const app = express();
app.use(cors({ origin: "*" }));
// app.use(limiter);

// Security
app.use("/", express.static(path.join(__dirname, "public")));
app.use(helmet());

app.use(express.json());
app.use("/api/v1", IndexRoute);

app.use(customErrorHandler);

const PORT = process.env.PORT;

const server = app.listen(PORT, () => {
  console.log(`Server running on port  ${PORT} : ${process.env.NODE_ENV}`);
});

process.on("unhandledRejection", (err, promise) => {
  console.log(`Logged Error : ${err}`);

  server.close(() => process.exit(1));
});
