class CustomError extends Error {
  constructor(message, statusCode) {
    super(message);

    this.statusCode = statusCode;

    // Use Error.captureStackTrace to capture the stack trace
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = CustomError;
