const mongoose = require("mongoose");
console.log(process.env.MONGO_URI);

const dbUri = process.env.MONGO_URI;
connectDatabase().catch((err) => console.log(err));

async function connectDatabase() {
  await mongoose.connect(dbUri);
  console.log("Db Conneted");
}

module.exports = connectDatabase;
